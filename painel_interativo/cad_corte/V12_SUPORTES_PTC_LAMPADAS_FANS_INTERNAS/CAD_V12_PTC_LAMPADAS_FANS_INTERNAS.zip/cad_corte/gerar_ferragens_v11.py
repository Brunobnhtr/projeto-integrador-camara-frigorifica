# -*- coding: utf-8 -*-
"""Lista de ferragens e de materiais da V11 — camara com DUTOS EXTERNOS.

Le `pecas_v11.json` (exportado por gerar_cad_v11.py) e escreve:
  lista_ferragens_v11.csv / .md
  lista_materiais_v11.csv / .md

As areas de material saem da geometria, nao de estimativa. As quantidades de
fixacao saem da contagem de furos das pecas. O que nao pode ser contado
(vedacao, silicone, dobradica) esta marcado ESTIMADO.
"""
from __future__ import annotations

import csv
import json
import os
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
import parametros_v11 as P

with open(os.path.join(BASE, 'pecas_v11.json'), encoding='utf-8') as f:
    PECAS = json.load(f)

# ---------------------------------------------------------------- areas -----
area = defaultdict(float)
pecas_por_mat = defaultdict(int)
for p in PECAS:
    area[(p['material'], p['esp'])] += p['w'] * p['h'] * p['qtd'] / 1e6
    pecas_por_mat[(p['material'], p['esp'])] += p['qtd']

# ------------------------------------------------------------- ferragens ----
F = []


def add(grupo, item, qtd, un, onde, obs=''):
    F.append({'grupo': grupo, 'item': item, 'quantidade': qtd, 'unidade': un,
              'onde': onde, 'observacao': obs})


# --- conjunto do PTC: 4 tirantes x 3 niveis ---------------------------------
add('PTC', f'Tirante M4 x {P.ROD_COMP:g} mm (varilla roscada)', 4, 'pc',
    'teto -> escudo', 'cortar de varilla de 1 m')
add('PTC', 'Porca M4 zincada', 4 * 8, 'pc',
    '2 por nivel x 4 niveis x 4 tirantes', 'teto, plataforma, suporte, escudo')
add('PTC', 'Arruela lisa M4', 4 * 8, 'pc', 'idem', '')
add('PTC', f'Tubo ceramico D6 x D4,2 x {P.GAP_TETO_PLAT:g} mm', 4, 'pc',
    'teto -> plataforma', 'isolamento termico; nao substituir por PVC')
add('PTC', f'Tubo ceramico D6 x D4,2 x {P.GAP_PLAT_SUP:g} mm', 4, 'pc',
    'plataforma -> suporte', 'isola o acrilico da face quente')
add('PTC', f'Tubo ceramico D6 x D4,2 x {P.GAP_SUP_ESC:g} mm', 4, 'pc',
    'suporte -> escudo', '')
add('PTC', 'Parafuso M4 x 12 inox', 4, 'pc', 'grampos do PTC', '')
add('PTC', 'Porca M4 inox', 4, 'pc', 'grampos do PTC', '')
add('PTC', 'PTC 110 x 30 x 20 mm', 1, 'pc', 'pendurado no teto',
    'POTENCIA A DEFINIR; 100 W fixos ja levam a camara acima de 95 C')

# --- lampadas ---------------------------------------------------------------
add('Lampadas', 'Lampada W5W 12 V / 5 W', P.LAMP_QTD, 'pc', 'suportes no teto',
    'NUNCA usar lampada de 12 V em 24 V; ligar em paralelo')
add('Lampadas', 'Soquete W5W', P.LAMP_QTD, 'pc', 'aba do suporte CAM-15',
    'medir antes de furar: o D20 da peca e so gravado')
add('Lampadas', 'Parafuso M4 x 16', 4, 'pc', 'suporte de lampada no teto', '')

# --- kit Peltier ------------------------------------------------------------
add('Peltier', 'Modulo TEC1-12706', 2, 'pc', 'tampa tecnica, face externa',
    'dois modulos em serie eletrica ou em paralelo, conforme a fonte')
add('Peltier', 'Dissipador frio (dentro)', 1, 'pc', 'face fria',
    'entra ~45 mm na camara; medir o kit antes de recortar')
add('Peltier', 'Dissipador quente (fora)', 1, 'pc', 'face quente',
    'tem de rejeitar ~185 W com Rth <= 0,15 K/W')
add('Peltier', 'Ventoinha do dissipador quente', 1, 'pc', 'lado externo',
    'nao e a mesma das recirculacao')
add('Peltier', 'Pasta termica', 1, 'seringa', 'entre TEC e dissipadores',
    'fina; pasta grossa aumenta a resistencia de contato')
add('Peltier', 'Parafuso M4 x 16', 6, 'pc', 'tampa tecnica no corpo', '')

# --- recirculacao -----------------------------------------------------------
add('Recirculacao', 'Ventoinha 40 x 40 x 10 mm, 12 V', 2, 'pc',
    'pe de cada duto externo', 'soprando para CIMA')
add('Recirculacao', 'Parafuso M3 x 16', 8, 'pc', 'flange CAM-11', '4 por ventoinha')
add('Recirculacao', 'Porca M3', 8, 'pc', 'flange CAM-11', '')
add('Recirculacao', 'Arruela M3', 8, 'pc', 'flange CAM-11', '')

# --- vedacao e montagem -----------------------------------------------------
perim = 2 * (P.PORTA_W + P.PORTA_H) / 1000
add('Vedacao', 'Perfil EPDM autoadesivo (bulbo)', round(perim, 2), 'm',
    'batente CAM-06', f'perimetro da porta = {perim:.2f} m; ESTIMADO com 10% de folga')
add('Vedacao', 'Silicone neutro (cartucho 300 g)', 2, 'pc',
    'todas as juntas coladas', 'ESTIMADO')
add('Vedacao', 'Fita aluminio 50 mm', 2, 'rolo', 'face quente e juntas do EPS',
    'ESTIMADO')
add('Vedacao', 'Fita EPDM para a comporta', 1, 'm', 'quadro CAM-18', 'ESTIMADO')
add('Montagem', 'Cola para acrilico (dicloroetano ou cianoacrilato gel)', 2, 'pc',
    'todas as juntas', 'ESTIMADO')
add('Montagem', 'Dobradica de acrilico', 2, 'pc', 'porta', 'ESTIMADO')
add('Montagem', 'Fecho/trinco da porta', 1, 'pc', 'porta', 'ESTIMADO')
add('Montagem', 'Puxador da comporta', 2, 'pc', 'lamina CAM-19', 'ESTIMADO')
add('Montagem', 'Premsa-cabo PG9', 1, 'pc', 'traseira fixa', 'potencia')
add('Montagem', 'Premsa-cabo PG7', 1, 'pc', 'traseira fixa', 'sinal')

# ------------------------------------------------------------- materiais ----
M = []
for (mat, esp), a in sorted(area.items()):
    M.append({'material': mat, 'espessura_mm': f'{esp:g}',
              'area_pecas_m2': f'{a:.4f}', 'pecas': pecas_por_mat[(mat, esp)],
              'area_com_perda_m2': f'{a * 1.15:.4f}',
              'observacao': 'area das pecas x 1,15 (perda de corte)'})

# ---------------------------------------------------------------- escrita ---
with open(os.path.join(BASE, 'lista_ferragens_v11.csv'), 'w', newline='',
          encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=['grupo', 'item', 'quantidade', 'unidade',
                                      'onde', 'observacao'], delimiter=';')
    w.writeheader()
    w.writerows(F)

with open(os.path.join(BASE, 'lista_materiais_v11.csv'), 'w', newline='',
          encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=['material', 'espessura_mm', 'area_pecas_m2',
                                      'pecas', 'area_com_perda_m2', 'observacao'],
                       delimiter=';')
    w.writeheader()
    w.writerows(M)

# ------------------------------------------------------------------- .md ----
L = []
L.append('# Ferragens e materiais — câmara V11 (dutos externos)\n')
L.append(f'Câmara {P.BODY_W:g} × {P.BODY_D:g} × {P.BODY_H:g} mm externo, '
         f'**{P.TOTAL_W:g} mm** de largura com os dois dutos. '
         f'{sum(p["qtd"] for p in PECAS)} peças físicas.\n')
L.append('> Áreas de material saem da geometria. Quantidades de fixação saem da '
         'contagem de furos. O que não pode ser contado está marcado **ESTIMADO**.\n')

L.append('\n## Ferragens\n')
L.append('| Grupo | Item | Qtd | Un | Onde | Obs |')
L.append('|---|---|---|---|---|---|')
for r in F:
    L.append(f'| {r["grupo"]} | {r["item"]} | {r["quantidade"]} | {r["unidade"]} | '
             f'{r["onde"]} | {r["observacao"]} |')

L.append('\n## Materiais\n')
L.append('| Material | Esp. | Área das peças | Peças | Com perda 15% |')
L.append('|---|---|---|---|---|')
for r in M:
    L.append(f'| {r["material"]} | {r["espessura_mm"]} mm | '
             f'{r["area_pecas_m2"]} m² | {r["pecas"]} | {r["area_com_perda_m2"]} m² |')

with open(os.path.join(BASE, 'LISTA_FERRAGENS_E_MATERIAIS_V11.md'), 'w',
          encoding='utf-8') as f:
    f.write('\n'.join(L) + '\n')

print(f'  ferragens: {len(F)} linhas')
print(f'  materiais: {len(M)} linhas')
for r in M:
    print(f'    {r["material"]:22} {r["espessura_mm"]:>4} mm  '
          f'{r["area_pecas_m2"]:>8} m2  ({r["pecas"]:2d} pecas)')
